#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "fx_cli::fx_cli_cpp" for configuration "Release"
set_property(TARGET fx_cli::fx_cli_cpp APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(fx_cli::fx_cli_cpp PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libfx_cli_cpp.a"
  )

list(APPEND _IMPORT_CHECK_TARGETS fx_cli::fx_cli_cpp )
list(APPEND _IMPORT_CHECK_FILES_FOR_fx_cli::fx_cli_cpp "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libfx_cli_cpp.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
